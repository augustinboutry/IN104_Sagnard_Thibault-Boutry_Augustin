#################### SHAP TITANIC ##############################################################

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

import xgboost 
import sklearn
import shap
import seaborn as sns
import pandas as pd
import string
import numpy as np
import os
import pickle
import re
import time
from sklearn.datasets import make_classification
from sklearn.ensemble import RandomForestRegressor # Pour le modèle ForestRegressor
from sklearn.ensemble import RandomForestClassifier # Pour le modèle ForestClassifier
from sklearn.model_selection import train_test_split
from IPython.core.display import HTML
from matplotlib import pyplot as plt
from sklearn.linear_model import LogisticRegression # Pour LogisticRegression



# load JS visualization code to notebook
shap.initjs()

# Exporter les fichiers sur kaggle
test_df = pd.read_csv("/kaggle/input/titanic/test.csv")
train_df = pd.read_csv("/kaggle/input/titanic/train.csv")

# tally missing data
total = train_df.isnull().sum().sort_values(ascending=False)
percent_1 = train_df.isnull().sum()/train_df.isnull().count()*100
percent_2 = (round(percent_1, 1)).sort_values(ascending=False)
missing_data = pd.concat([total, percent_2], axis=1, keys=['#missing', '%'])
display(missing_data.head(5))

# form number of family members on board with each passenger
data = [train_df, test_df]
for dataset in data:
    dataset['num_family'] = dataset['SibSp'] + dataset['Parch']
    
train_df.drop(columns=['SibSp','Parch'],inplace=True)
test_df.drop(columns=['SibSp','Parch'],inplace=True)

# rename some columns
train_df.rename(columns=dict(Pclass='ticket_class', PassengerId='passenger_id'),inplace=True)
test_df.rename(columns=dict(Pclass='ticket_class', PassengerId='passenger_id'),inplace=True)

# from the Cabin number we can parse the deck level
# level 8 represents a deck level that we could not infer from the Cabin number
# or where the Cabin number was missing
deck = {"A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "U": 8}
data = [train_df, test_df]

for dataset in data:
    dataset['Cabin'] = dataset['Cabin'].fillna("U0")
    dataset['deck'] = dataset['Cabin'].map(lambda x: re.compile("([a-zA-Z]+)").search(x).group())
    dataset['deck'] = dataset['deck'].map(deck)
    dataset['deck'] = dataset['deck'].fillna(0)
    dataset['deck'] = dataset['deck'].astype(int)
    dataset['deck'] = dataset['deck'].fillna('NA')

# we can now drop the cabin feature
train_df.drop(columns=['Cabin'], inplace=True)
test_df.drop(columns=['Cabin'], inplace=True)

# age imputation
# https://www.mikulskibartosz.name/fill-missing-values-using-random-forest/

def impute_age(titanic):

    titanic[titanic==np.inf]=np.nan
    got_age = pd.isnull(titanic['Age']) == False

    titanicWithAge = titanic[got_age]
    titanicWithoutAge = titanic[~got_age]
    variables = ['ticket_class', 'num_family', 'Fare', 'Age','passenger_id']
    one_hot_encoded_embarked = pd.get_dummies(titanicWithAge['Embarked'], prefix='emb')
    one_hot_encoded_sex = pd.get_dummies(titanicWithAge['Sex'])
    titanicWithAge = titanicWithAge[variables]
    titanicWithAge = pd.concat([titanicWithAge, one_hot_encoded_sex, one_hot_encoded_embarked], axis = 1)

    one_hot_encoded_embarked = pd.get_dummies(titanicWithoutAge['Embarked'], prefix='emb')
    one_hot_encoded_sex = pd.get_dummies(titanicWithoutAge['Sex'])
    titanicWithoutAge = titanicWithoutAge[variables]
    titanicWithoutAge = pd.concat([titanicWithoutAge, one_hot_encoded_sex, one_hot_encoded_embarked], axis = 1)

    independentVariables = ['ticket_class', 'female', 'male', 'num_family', 'Fare', 
                            'emb_C', 'emb_Q', 'emb_S']


###  /!\ A CHANGER SELON LES MODELES UTILISES
    rfModel_age = RandomForestRegressor(random_state=100) # Pour le modèle ForestRegressor
    rfModel_age = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=1) # Pour le modèle ForestClassifier
    rfModel_age = LogisticRegression(penalty='none',solver='newton-cg') # Pour le modèle LogisticRegression


    rfModel_age.fit(titanicWithAge[independentVariables].astype('int'), titanicWithAge['Age'].astype('int'))

    generatedAgeValues = rfModel_age.predict(X = titanicWithoutAge[independentVariables])

    titanicWithoutAge['Age'] = generatedAgeValues.astype(int)
    data = titanicWithAge.append(titanicWithoutAge)
    data = data[['Age','passenger_id','emb_C', 'emb_Q', 'emb_S']]
    data.rename(columns=dict(Age='age'), inplace=True)
    
    return data

train_imputed_df = train_df.drop(columns='Age').merge(impute_age(train_df), on='passenger_id')
train_imputed_df['age'] = train_imputed_df['age'].astype(int)

test_df.dropna(subset=['Fare'], inplace=True) # a few missing values here...just nix
test_imputed_df = test_df.drop(columns='Age').merge(impute_age(test_df), on='passenger_id')
test_imputed_df['age'] = test_imputed_df['age'].astype(int)

# Fare is the price for multiple people in the party.
# Correct by calculating ticket_price per individual.

def price_per_passenger(x):
    return round(x.mean() / len(x), 2)

price_per_passenger_df = train_imputed_df.groupby('Ticket').Fare.agg(price_per_passenger).to_frame().reset_index()
price_per_passenger_df.rename(columns=dict(Fare='ticket_price'), inplace=True)
train_imputed_df = train_imputed_df.merge(price_per_passenger_df, on='Ticket', how='left')
train_imputed_df.drop(columns=['Fare','Ticket'], inplace=True)

genders = {"male": 0, "female": 1}

titles = {"Mr": 1, "Miss": 2, "Mrs": 3, "Master": 4, "Rare": 5}

rare_titles = ['Lady', 'Countess','Capt', 'Col','Don', 'Dr',
                'Major', 'Rev', 'Sir', 'Jonkheer', 'Dona']

cols_to_drop = ['Name', 'Embarked','Sex']

data = [train_imputed_df, test_imputed_df]

np.random.seed(1)

for dataset in data:
    
    # set gender logical
    dataset['is_female'] = dataset['Sex'].map(genders)
    
    # extract titles
    dataset['title'] = dataset.Name.str.extract(' ([A-Za-z]+)\.', expand=False)
    # replace titles with a more common title or as Rare
    dataset['title'] = dataset['title'].replace(rare_titles, 'Rare')
    dataset['title'] = dataset['title'].replace('Mlle', 'Miss')
    dataset['title'] = dataset['title'].replace('Ms', 'Miss')
    dataset['title'] = dataset['title'].replace('Mme', 'Mrs')
    
    # convert titles into numbers
    dataset['title'] = dataset['title'].map(titles)
    # filling NaN with 0, to get safe
    dataset['title'] = dataset['title'].fillna(0)

    # add silly feature to test feature importance
    dataset['surname_length'] = [len(s[0]) for s in dataset.Name.str.split(',')]
    dataset['random'] = np.random.randint(1,100, len(dataset))
    
    # drop columns
    dataset.drop(columns=cols_to_drop, inplace=True)


X_train_df = train_imputed_df.drop(columns=['Survived'])
X_train_df.set_index('passenger_id', inplace=True)
y_train = train_imputed_df['Survived'].values

X_train_with_survival_df = X_train_df.copy()
X_train_with_survival_df['survived'] = y_train
display(X_train_with_survival_df)

# train a model
model = xgboost.train({"learning_rate": 0.01, "seed":100}, 
                      xgboost.DMatrix(X_train_df, label=y_train, enable_categorical=True), 
                      100)

# explain the model's predictions using SHAP
# (same syntax works for LightGBM, CatBoost, scikit-learn and spark models)
explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_train_df)

shap_values_df = pd.DataFrame(shap_values)
shap_values_df['passenger_id'] = X_train_df.index.values
shap_values_df.set_index('passenger_id', inplace=True)


######## CHOIX DES PASSAGERS ##################
# row_sample = np.random.randint(0, len(X_train_df), 3)
pid_sample = [1, #166, # young and survived
             2, # model not confident they will survive, 
             3, #high title
             ]

# display title code for reference since it appears in
# the force plots
display(HTML('<h3 style="color:cornflowerblue">TITLE CODES</h3>'))
display(pd.DataFrame(titles, index=[0]).style.hide_index())
display(HTML('<h3 style="color:cornflowerblue">SAMPLE SHAP EXPLANATIONS</h3>'))


############## REGARDER LES PREDICTIONS ###################
for pid in pid_sample:
    passenger = X_train_df.loc[[pid]]
    passenger_shap_values = shap_values_df.loc[pid].values
    display(passenger.reset_index().style.hide_index().set_precision(2))#.set_table_styles(styles))
    display(shap.force_plot(explainer.expected_value, passenger_shap_values, passenger))
    

shap.force_plot(explainer.expected_value, shap_values, X_train_df)
shap.summary_plot(shap_values, X_train_df)
shap.summary_plot(shap_values, X_train_df, plot_type="bar")






