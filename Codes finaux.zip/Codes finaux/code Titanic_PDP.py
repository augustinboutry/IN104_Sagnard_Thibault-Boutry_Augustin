### CODE TITANIC METHODE PDP

## Nous avons rédigé le code ci-dessous avec kaggle



import pandas as pd
from pdpbox import pdp, get_dataset, info_plots
import xgboost
from xgboost import XGBClassifier
import matplotlib
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
​
test_titanic = get_dataset.titanic()
titanic_target = test_titanic['target']
​
#Interaction entre Age et Fare:
fig, axes, summary_df = info_plots.target_plot_interact(
    df=titanic_data, features=['Age', 'Fare'], feature_names=['Age', 'Fare'], target=titanic_target
)
#Interaction entre Age et Sex:
fig, axes, summary_df = info_plots.target_plot_interact(
    df=titanic_data, features=['Age', 'Sex'], feature_names=['Age', 'Sexe'], target=titanic_target
)
#Interaction entre Sex et Pclass:
fig, axes, summary_df = info_plots.target_plot_interact(
    df=titanic_data, features=['Sex', 'Pclass'], feature_names=['Sex', 'Pclass'], target=titanic_target
)

# Et on peut faire pareil pour observer l'influence des différents autres paramètres : sibsp, parch, ticket, cabin et embarked